"use strict";
var SessionSwitcher = (() => {
  // src/shared/constants/storageKeys.ts
  var STORAGE_KEYS = {
    SESSIONS: "sessions",
    ACTIVE_SESSIONS: "activeSessions"
  };

  // src/shared/utils/errorHandling.ts
  var ExtensionError = class extends Error {
    constructor(message, code) {
      super(message);
      this.code = code;
      this.name = "ExtensionError";
    }
  };
  function handleError(error, context) {
    console.error(`Error in ${context}:`, error);
    if (error instanceof ExtensionError) {
      return error.message;
    }
    if (error instanceof Error) {
      return error.message;
    }
    return "An unexpected error occurred";
  }

  // src/background/handlers/cookie.handler.ts
  var CookieHandler = class {
    async getCookiesForDomain(domain) {
      try {
        const stores = await chrome.cookies.getAllCookieStores();
        const allCookies = [];
        const currentDomain = domain.split(":")[0];
        for (const store of stores) {
          const cookies = await chrome.cookies.getAll({ storeId: store.id });
          const domainCookies = cookies.filter((cookie) => {
            const slicedCookieDomain = cookie.domain.startsWith(".") ? cookie.domain.slice(1) : cookie.domain;
            return slicedCookieDomain === currentDomain || slicedCookieDomain === `www.${currentDomain}` || currentDomain.endsWith(slicedCookieDomain);
          });
          allCookies.push(...domainCookies);
        }
        return allCookies;
      } catch (error) {
        console.error("Error getting cookies for domain:", domain, error);
        return [];
      }
    }
    async clearCookiesForDomain(domain) {
      const cookies = await this.getCookiesForDomain(domain);
      const clearPromises = cookies.map(async (cookie) => {
        try {
          await chrome.cookies.remove({
            url: this.buildCookieUrl(cookie, domain),
            name: cookie.name,
            storeId: cookie.storeId
          });
        } catch (error) {
          console.warn("Failed to remove cookie:", cookie.name, error);
        }
      });
      await Promise.all(clearPromises);
    }
    async restoreCookies(cookies, domain) {
      const restorePromises = cookies.map(async (cookie) => {
        try {
          const cookieDetails = this.prepareCookieForRestore(cookie, domain);
          await chrome.cookies.set(cookieDetails);
        } catch (error) {
          console.warn("Failed to restore cookie:", cookie.name, error);
        }
      });
      await Promise.all(restorePromises);
    }
    buildCookieUrl(cookie, fallbackDomain) {
      const protocol = cookie.secure ? "https" : "http";
      let domain = cookie.domain;
      if (domain.startsWith(".")) {
        domain = domain.slice(1);
      }
      if (!domain && fallbackDomain) {
        domain = fallbackDomain;
      }
      if (!domain) {
        throw new Error(`Invalid domain for cookie ${cookie.name}: ${cookie.domain}`);
      }
      const path = cookie.path || "/";
      return `${protocol}://${domain}${path}`;
    }
    prepareCookieForRestore(cookie, fallbackDomain) {
      const url = this.buildCookieUrl(cookie, fallbackDomain);
      const cookieDetails = {
        url,
        name: cookie.name,
        value: cookie.value,
        path: cookie.path,
        secure: cookie.secure,
        httpOnly: cookie.httpOnly,
        storeId: cookie.storeId
      };
      if (cookie.domain && cookie.domain.startsWith(".")) {
        cookieDetails.domain = cookie.domain;
      }
      if (!cookie.session && cookie.expirationDate) {
        cookieDetails.expirationDate = cookie.expirationDate;
      }
      if (cookie.sameSite && cookie.sameSite !== "unspecified") {
        cookieDetails.sameSite = cookie.sameSite;
      }
      return cookieDetails;
    }
  };

  // src/background/services/storageData.service.ts
  function extractStorageData() {
    try {
      const localStorageData = {};
      const sessionStorageData = {};
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key) {
          const value = localStorage.getItem(key);
          if (value !== null) {
            localStorageData[key] = value;
          }
        }
      }
      for (let i = 0; i < sessionStorage.length; i++) {
        const key = sessionStorage.key(i);
        if (key) {
          const value = sessionStorage.getItem(key);
          if (value !== null) {
            sessionStorageData[key] = value;
          }
        }
      }
      return {
        localStorage: localStorageData,
        sessionStorage: sessionStorageData
      };
    } catch (error) {
      console.error("Error extracting storage data:", error);
      return { localStorage: {}, sessionStorage: {} };
    }
  }
  function injectStorageData(localData, sessionData) {
    try {
      localStorage.clear();
      sessionStorage.clear();
      Object.entries(localData).forEach(([key, value]) => {
        localStorage.setItem(key, value);
      });
      Object.entries(sessionData).forEach(([key, value]) => {
        sessionStorage.setItem(key, value);
      });
      return true;
    } catch (error) {
      console.error("Error injecting storage data:", error);
      return false;
    }
  }
  function clearStorage() {
    try {
      localStorage.clear();
      sessionStorage.clear();
      return true;
    } catch (error) {
      console.error("Error clearing storage:", error);
      return false;
    }
  }

  // src/background/handlers/storage.handler.ts
  var StorageHandler = class {
    async getStorageData(tabId) {
      try {
        const results = await chrome.scripting.executeScript({
          target: { tabId },
          func: extractStorageData
        });
        return results?.[0]?.result || { localStorage: {}, sessionStorage: {} };
      } catch (error) {
        console.error("Error getting storage data:", error);
        return { localStorage: {}, sessionStorage: {} };
      }
    }
    async restoreStorageData(tabId, data) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId },
          func: injectStorageData,
          args: [data.localStorage, data.sessionStorage]
        });
      } catch (error) {
        throw new ExtensionError(`Failed to restore storage data: ${error}`);
      }
    }
    async clearStorageData(tabId) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId },
          func: clearStorage
        });
      } catch (error) {
        throw new ExtensionError(`Failed to clear storage data: ${error}`);
      }
    }
  };

  // src/background/handlers/session.handler.ts
  var SessionHandler = class {
    constructor() {
      this.cookieHandler = new CookieHandler();
      this.storageHandler = new StorageHandler();
    }
    async getCurrentSession(domain, tabId) {
      try {
        const [cookies, storageData] = await Promise.all([
          this.cookieHandler.getCookiesForDomain(domain),
          this.storageHandler.getStorageData(tabId)
        ]);
        return {
          cookies,
          localStorage: storageData.localStorage,
          sessionStorage: storageData.sessionStorage
        };
      } catch (error) {
        throw new ExtensionError(`Failed to get current session: ${error}`);
      }
    }
    async switchToSession(sessionData, tabId) {
      const { domain, cookies, localStorage: localStorage2, sessionStorage: sessionStorage2 } = sessionData;
      try {
        await this.cookieHandler.clearCookiesForDomain(domain);
        await Promise.all([
          this.cookieHandler.restoreCookies(cookies, domain),
          this.storageHandler.restoreStorageData(tabId, {
            localStorage: localStorage2,
            sessionStorage: sessionStorage2
          })
        ]);
        await chrome.tabs.reload(tabId);
      } catch (error) {
        throw new ExtensionError(`Failed to switch session: ${error}`);
      }
    }
    async clearSession(domain, tabId) {
      try {
        await Promise.all([
          this.cookieHandler.clearCookiesForDomain(domain),
          this.storageHandler.clearStorageData(tabId)
        ]);
        await chrome.tabs.reload(tabId);
      } catch (error) {
        throw new ExtensionError(`Failed to clear session: ${error}`);
      }
    }
  };

  // src/shared/constants/messages.ts
  var MESSAGE_ACTIONS = {
    GET_CURRENT_SESSION: "getCurrentSession",
    SWITCH_SESSION: "switchSession",
    CLEAR_SESSION: "clearSession"
  };

  // src/shared/constants/requiredPermission.ts
  var REQUIRED_PERMISSIONS = [
    "storage",
    "tabs",
    "cookies",
    "activeTab",
    "scripting"
  ];

  // src/background/services/message.service.ts
  var MessageService = class {
    constructor() {
      this.sessionHandler = new SessionHandler();
    }
    handleMessage(message, _, sendResponse) {
      this.checkPermissions().then(() => {
        return this.processMessage(message, sendResponse);
      }).catch((error) => {
        const errorMessage = handleError(error, "MessageService.handleMessage");
        sendResponse({ success: false, error: errorMessage });
      });
      return true;
    }
    async checkPermissions() {
      try {
        const permissions = await chrome.permissions.getAll();
        this.validateRequiredPermissions(permissions);
        this.validateOriginPermissions(permissions);
      } catch (error) {
        throw error;
      }
    }
    validateRequiredPermissions(permissions) {
      for (const permission of REQUIRED_PERMISSIONS) {
        if (!permissions.permissions?.includes(permission)) {
          throw new Error("Data access permission is required.");
        }
      }
    }
    validateOriginPermissions(permissions) {
      const origins = permissions.origins || [];
      if (origins.length === 0) {
        throw new Error("Data access permission is required.");
      }
      const hasBroadAccess = origins.some(
        (origin) => origin === "<all_urls>" || origin === "*://*/*" || origin === "http://*/*" || origin === "https://*/*"
      );
      if (!hasBroadAccess) {
        throw new Error("Data access permission is required.");
      }
    }
    async processMessage(message, sendResponse) {
      switch (message.action) {
        case MESSAGE_ACTIONS.GET_CURRENT_SESSION:
          await this.handleGetCurrentSession(message, sendResponse);
          break;
        case MESSAGE_ACTIONS.SWITCH_SESSION:
          await this.handleSwitchSession(message, sendResponse);
          break;
        case MESSAGE_ACTIONS.CLEAR_SESSION:
          await this.handleClearSession(message, sendResponse);
          break;
        default:
          sendResponse({ success: false, error: "Unknown action" });
      }
    }
    async handleGetCurrentSession(message, sendResponse) {
      const sessionData = await this.sessionHandler.getCurrentSession(message.domain, message.tabId);
      sendResponse({ success: true, data: sessionData });
    }
    async handleSwitchSession(message, sendResponse) {
      await this.sessionHandler.switchToSession(message.sessionData, message.tabId);
      sendResponse({ success: true });
    }
    async handleClearSession(message, sendResponse) {
      await this.sessionHandler.clearSession(message.domain, message.tabId);
      sendResponse({ success: true });
    }
  };

  // src/background/index.ts
  var messageService = new MessageService();
  chrome.runtime.onStartup.addListener(() => {
    console.log("Session Switcher extension started");
  });
  chrome.runtime.onInstalled.addListener((details) => {
    console.log("Session Switcher extension installed/updated", details);
    if (details.reason === "install") {
      chrome.storage.local.set({
        [STORAGE_KEYS.SESSIONS]: [],
        [STORAGE_KEYS.ACTIVE_SESSIONS]: {}
      });
    }
  });

  // ═══════════════════════════════════════════════════════════════════════════
  // GOOGLE DRIVE — обработчики в background (единственное место где работает
  // chrome.identity в MV3)
  // ═══════════════════════════════════════════════════════════════════════════

  const DRIVE_FILE_NAME = "session-switcher-backup.json";
  const DRIVE_API_FILES = "https://www.googleapis.com/drive/v3/files";
  const DRIVE_API_UPLOAD = "https://www.googleapis.com/upload/drive/v3/files";

  function getAuthToken(interactive) {
    return new Promise((resolve, reject) => {
      chrome.identity.getAuthToken({ interactive }, (token) => {
        if (chrome.runtime.lastError || !token) {
          reject(new Error(chrome.runtime.lastError?.message || "Auth failed"));
        } else {
          resolve(token);
        }
      });
    });
  }

  function removeCachedToken(token) {
    return new Promise((resolve) => {
      chrome.identity.removeCachedAuthToken({ token }, resolve);
    });
  }

  async function findBackupFile(token) {
    const query = encodeURIComponent(`name='${DRIVE_FILE_NAME}' and trashed=false`);
    const res = await fetch(`${DRIVE_API_FILES}?q=${query}&fields=files(id,name)`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    if (!res.ok) throw new Error(`Drive search failed: ${res.status}`);
    const data = await res.json();
    return data.files?.[0] || null;
  }

  async function uploadToDrive(token, jsonData) {
    const blob = new Blob([JSON.stringify(jsonData, null, 2)], { type: "application/json" });
    const existing = await findBackupFile(token);
    const url = existing
      ? `${DRIVE_API_UPLOAD}/${existing.id}?uploadType=multipart`
      : `${DRIVE_API_UPLOAD}?uploadType=multipart`;
    const method = existing ? "PATCH" : "POST";

    const form = new FormData();
    form.append("metadata", new Blob([JSON.stringify({ name: DRIVE_FILE_NAME, mimeType: "application/json" })], { type: "application/json" }));
    form.append("file", blob);

    const res = await fetch(url, { method, headers: { Authorization: `Bearer ${token}` }, body: form });
    if (!res.ok) throw new Error(`Upload failed: ${res.status} — ${await res.text()}`);
    return res.json();
  }

  async function downloadFromDrive(token) {
    const existing = await findBackupFile(token);
    if (!existing) return null;
    const res = await fetch(`${DRIVE_API_FILES}/${existing.id}?alt=media`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    if (!res.ok) throw new Error(`Download failed: ${res.status}`);
    return res.json();
  }

  // Обработчик Drive-сообщений от popup
  async function handleDriveMessage(message, sendResponse) {
    try {
      switch (message.action) {

        case "DRIVE_CONNECT": {
          // Сбрасываем старый токен — чтобы всегда показывался выбор аккаунта
          try {
            const old = await getAuthToken(false);
            await removeCachedToken(old);
          } catch (_) { /* токена не было — ок */ }
          await getAuthToken(true); // показывает окно выбора
          await chrome.storage.local.set({ driveConnected: true });
          sendResponse({ success: true, data: { connected: true } });
          break;
        }

        case "DRIVE_CHECK": {
          try {
            await getAuthToken(false); // без UI
            await chrome.storage.local.set({ driveConnected: true });
            sendResponse({ success: true, data: { connected: true } });
          } catch (_) {
            await chrome.storage.local.set({ driveConnected: false });
            sendResponse({ success: true, data: { connected: false } });
          }
          break;
        }

        case "DRIVE_UPLOAD": {
          const token = await getAuthToken(false);
          const stored = await chrome.storage.local.get(null);
          const payload = {
            version: 1,
            exportedAt: new Date().toISOString(),
            sessions: stored.sessions || [],
            activeSessions: stored.activeSessions || {}
          };
          await uploadToDrive(token, payload);
          sendResponse({ success: true, data: {} });
          break;
        }

        case "DRIVE_DOWNLOAD": {
          const token = await getAuthToken(false);
          const cloudData = await downloadFromDrive(token);
          if (!cloudData) {
            sendResponse({ success: false, error: "No backup file found on Google Drive. Upload first." });
            break;
          }
          if (message.mode === "replace") {
            await chrome.storage.local.set({
              sessions: cloudData.sessions || [],
              activeSessions: cloudData.activeSessions || {}
            });
          } else {
            // merge
            const local = await chrome.storage.local.get(["sessions", "activeSessions"]);
            const localSessions = local.sessions || [];
            const cloudSessions = cloudData.sessions || [];
            const existingIds = new Set(localSessions.map((s) => s.id));
            const newSessions = cloudSessions.filter((s) => !existingIds.has(s.id));
            await chrome.storage.local.set({
              sessions: [...localSessions, ...newSessions],
              activeSessions: { ...(cloudData.activeSessions || {}), ...(local.activeSessions || {}) }
            });
          }
          sendResponse({ success: true, data: {} });
          break;
        }

        default:
          return false; // не наш action — передаём дальше
      }
    } catch (err) {
      console.error("Drive handler error:", err);
      sendResponse({ success: false, error: err.message || "Unknown drive error" });
    }
    return true;
  }

  // Единый listener — сначала пробуем Drive, потом основной MessageService
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action && message.action.startsWith("DRIVE_")) {
      handleDriveMessage(message, sendResponse);
      return true; // async response
    }
    return messageService.handleMessage(message, sender, sendResponse);
  });

})();