"use strict";

/**
 * drive-ui.js  —  popup/drive-ui.js
 * UI-логика для кнопок Connect / Upload / Download.
 * Зависит от google-drive.js (должен быть подключён раньше в index.html).
 *
 * После download вызывает window.__popupCtrl.refreshFromStorage() —
 * это перечитывает storage и перерисовывает список через родной SessionList,
 * поэтому drag-and-drop работает сразу без перезапуска попапа.
 */

const connectBtn    = document.getElementById("connectBtn");
const uploadBtn     = document.getElementById("uploadBtn");
const downloadBtn   = document.getElementById("downloadBtn");
const downloadModal = document.getElementById("downloadModal");

// ─── UI STATE ────────────────────────────────────────────────────────────────

function setConnectedUI(connected) {
  if (connected) {
    connectBtn.innerHTML = "✅ Connected";
    connectBtn.classList.add("connected");
    uploadBtn.disabled   = false;
    downloadBtn.disabled = false;
  } else {
    connectBtn.innerHTML = '<span class="btn-icon">🔗</span> Connect';
    connectBtn.classList.remove("connected");
    uploadBtn.disabled   = true;
    downloadBtn.disabled = true;
  }
  connectBtn.disabled = false;
}

function showDriveError(msg) {
  document.getElementById("errorMessage").textContent = msg;
  document.getElementById("errorModal").classList.add("show");
}

// ─── REFRESH LIST ────────────────────────────────────────────────────────────

/**
 * Обновляет список сессий через PopupController.
 * SessionList хранит все drag-and-drop обработчики на контейнере (event delegation),
 * поэтому достаточно просто перерендерить innerHTML — обработчики остаются живыми.
 */
async function refreshSessionsList() {
  const ctrl = window.__popupCtrl;
  if (ctrl && typeof ctrl.refreshFromStorage === "function") {
    await ctrl.refreshFromStorage();
  }
}

// ─── INIT: тихая проверка токена ─────────────────────────────────────────────
(async () => {
  try {
    const connected = await driveCheckConnection();
    setConnectedUI(connected);
  } catch (_) {
    setConnectedUI(false);
  }
})();

// ─── CONNECT ─────────────────────────────────────────────────────────────────
connectBtn.addEventListener("click", async () => {
  connectBtn.disabled = true;
  connectBtn.innerHTML = "⏳ …";
  try {
    await driveConnect();
    setConnectedUI(true);
  } catch (err) {
    setConnectedUI(false);
    showDriveError("Could not connect to Google: " + err.message);
  }
});

// ─── UPLOAD ──────────────────────────────────────────────────────────────────
uploadBtn.addEventListener("click", async () => {
  uploadBtn.disabled = true;
  uploadBtn.innerHTML = "⏳ …";
  try {
    await driveUpload();
    uploadBtn.innerHTML = "✅ Saved!";
    setTimeout(() => {
      uploadBtn.innerHTML = '<span class="btn-icon">☁️</span> Upload';
      uploadBtn.disabled = false;
    }, 2000);
  } catch (err) {
    uploadBtn.innerHTML = '<span class="btn-icon">☁️</span> Upload';
    uploadBtn.disabled = false;
    showDriveError("Upload failed: " + err.message);
  }
});

// ─── DOWNLOAD ────────────────────────────────────────────────────────────────
downloadBtn.addEventListener("click", () => {
  downloadModal.classList.add("show");
});

document.getElementById("closeDownloadModal").addEventListener("click", () => {
  downloadModal.classList.remove("show");
});
document.getElementById("cancelDownload").addEventListener("click", () => {
  downloadModal.classList.remove("show");
});

async function handleDownload(mode) {
  downloadModal.classList.remove("show");
  downloadBtn.disabled = true;
  downloadBtn.innerHTML = "⏳ …";
  try {
    await driveDownload(mode);

    // Перерисовываем список через родной контроллер — drag-and-drop работает сразу
    await refreshSessionsList();

    downloadBtn.innerHTML = "✅ Done!";
    setTimeout(() => {
      downloadBtn.innerHTML = '<span class="btn-icon">⬇️</span> Download';
      downloadBtn.disabled = false;
    }, 1500);
  } catch (err) {
    downloadBtn.innerHTML = '<span class="btn-icon">⬇️</span> Download';
    downloadBtn.disabled = false;
    showDriveError("Download failed: " + err.message);
  }
}

document.getElementById("confirmReplace").addEventListener("click", () => handleDownload("replace"));
document.getElementById("confirmMerge").addEventListener("click",   () => handleDownload("merge"));