"use strict";
(() => {
// src/shared/utils/domain.ts
function extractDomain(hostname) { return hostname.replace(/^www\./, ""); }
function getDomainFromUrl(url) {
  try {
    const urlObj = new URL(url);
    const domain = extractDomain(urlObj.hostname);
    const isLocalhost = domain === "localhost" || domain.startsWith("127.");
    const port = urlObj.port;
    return isLocalhost && port ? `${domain}:${port}` : domain;
  } catch (_) { return ""; }
}

// src/shared/utils/errorHandling.ts
var ExtensionError = class extends Error { constructor(message, code) { super(message); this.code = code; this.name = "ExtensionError"; } };
function handleError(error, context) {
  console.error(`Error in ${context}:`, error);
  return error instanceof Error ? error.message : "An unexpected error occurred";
}

// src/popup/utils/constants.ts
var CSS_CLASSES = { SHOW: "show", LOADING: "loading", ACTIVE: "active", SESSION_ITEM: "session-item", SESSION_BTN: "session-btn", NO_SESSIONS: "no-sessions" };
var UI_TEXT = { NO_SESSIONS: "No sessions saved for this site", LAST_USED: "Last used: " };

// src/popup/components/loadingManager.ts
var LoadingManager = class {
  constructor() { this.isLoading = false; }
  showLoading() { if (!this.isLoading) { document.body.style.opacity = "0.7"; document.body.style.pointerEvents = "none"; this.isLoading = true; } }
  hideLoading() { if (this.isLoading) { document.body.style.opacity = "1"; document.body.style.pointerEvents = "auto"; this.isLoading = false; } }
  async withLoading(operation) { try { this.showLoading(); return await operation(); } finally { this.hideLoading(); } }
};

// src/popup/utils/dom.ts
function escapeHtml(text) { const div = document.createElement("div"); div.textContent = text; return div.innerHTML; }
function getElementByIdSafe(id) { const el = document.getElementById(id); if (!el) throw new Error(`Element not found: ${id}`); return el; }

// src/popup/components/modalManager.ts
var ModalManager = class {
  constructor() {
    this.modals = { save: getElementByIdSafe("saveModal"), rename: getElementByIdSafe("renameModal"), delete: getElementByIdSafe("deleteModal"), error: getElementByIdSafe("errorModal") };
    this.inputs = { sessionName: getElementByIdSafe("sessionName"), newSessionName: getElementByIdSafe("newSessionName") };
    this.setupEventListeners();
  }
  setupEventListeners() {
    const closes = [{id:"closeSaveModal",m:"save"},{id:"cancelSave",m:"save"},{id:"closeRenameModal",m:"rename"},{id:"cancelRename",m:"rename"},{id:"closeDeleteModal",m:"delete"},{id:"cancelDelete",m:"delete"},{id:"closeErrorModal",m:"error"},{id:"closeErrorModalBtn",m:"error"}];
    closes.forEach(({id,m}) => getElementByIdSafe(id).addEventListener("click", () => this.hide(m)));
    this.inputs.sessionName.addEventListener("keydown", e => { if(e.key==="Enter"){e.preventDefault();getElementByIdSafe("confirmSave").click();} });
    this.inputs.newSessionName.addEventListener("keydown", e => { if(e.key==="Enter"){e.preventDefault();getElementByIdSafe("confirmRename").click();} });
    document.addEventListener("keydown", e => {
      if(e.key==="Escape") this.hideVisible();
      if(e.key==="Enter") { if(this.isVisible("delete")) { e.preventDefault(); getElementByIdSafe("confirmDelete").click(); } if(this.isVisible("error")) { e.preventDefault(); getElementByIdSafe("closeErrorModal").click(); } }
    });
    Object.entries(this.modals).forEach(([k, m]) => m.addEventListener("click", e => { if(e.target===m) this.hide(k); }));
  }
  showSaveModal(n="Unnamed Session") { this.inputs.sessionName.value=n; this.show("save"); this.inputs.sessionName.focus(); this.inputs.sessionName.select(); }
  showRenameModal(n) { this.inputs.newSessionName.value=n; this.show("rename"); this.inputs.newSessionName.focus(); this.inputs.newSessionName.select(); }
  showDeleteModal(n) { const el=document.getElementById("deleteSessionName"); if(el) el.textContent=n; this.show("delete"); this.modals.delete.focus(); }
  showErrorModal(msg) { const el=document.getElementById("errorMessage"); if(el) el.textContent=msg; this.show("error"); this.modals.error.focus(); }
  getSaveInput() { return this.inputs.sessionName.value.trim(); }
  getRenameInput() { return this.inputs.newSessionName.value.trim(); }
  hideAll() { this.hideVisible(); this.inputs.sessionName.value=""; this.inputs.newSessionName.value=""; }
  isVisible(k) { return this.modals[k]?.classList.contains(CSS_CLASSES.SHOW) || false; }
  hideVisible() { Object.values(this.modals).forEach(m => m.classList.remove(CSS_CLASSES.SHOW)); }
  show(k) { this.modals[k].classList.add(CSS_CLASSES.SHOW); }
  hide(k) { this.modals[k].classList.remove(CSS_CLASSES.SHOW); }
};

// src/shared/utils/date.ts
function formatDate(ts) { return new Date(ts).toLocaleDateString(); }

// src/popup/components/sessionList.ts
var SessionList = class {
  constructor(c) { this.dragged=this.draggedOver=null; this.c=c; c.addEventListener("click", this.onClick.bind(this)); c.addEventListener("dragstart", this.onDragStart.bind(this)); c.addEventListener("dragover", e=>e.preventDefault()); c.addEventListener("dragenter", this.onDragEnter.bind(this)); c.addEventListener("dragleave", this.onDragLeave.bind(this)); c.addEventListener("drop", this.onDrop.bind(this)); c.addEventListener("dragend", this.onDragEnd.bind(this)); }
  setHandlers(h) { this.onSess=h.onSessionClick; this.onRename=h.onRenameClick; this.onDelete=h.onDeleteClick; this.onReorder=h.onReorder; }
  render(sess, active, dom) {
    const dSess = sess.filter(s=>s.domain===dom).sort((a,b)=>(a.order??0)-(b.order??0));
    if(!dSess.length) { this.c.innerHTML=`<div class="${CSS_CLASSES.NO_SESSIONS}">${UI_TEXT.NO_SESSIONS}</div>`; return; }
    this.c.innerHTML = dSess.map(s => {
      const act = s.id===active[dom];
      return `<div class="${CSS_CLASSES.SESSION_ITEM} ${act?CSS_CLASSES.ACTIVE:''}" data-id="${s.id}" draggable="true">
        <div class="session-progress"></div>
        <div class="drag-handle">⋮⋮</div>
        <div class="session-info"><div class="session-name">${escapeHtml(s.name)}</div><div class="session-meta">${UI_TEXT.LAST_USED} ${formatDate(s.lastUsed)}</div></div>
        <div class="session-actions">
          <button class="${CSS_CLASSES.SESSION_BTN} rename-btn" data-act="rename" data-id="${s.id}">✏️</button>
          <button class="${CSS_CLASSES.SESSION_BTN} delete-btn" data-act="delete" data-id="${s.id}">🗑️</button>
        </div></div>`;
    }).join("");
  }
  onClick(e) {
    if(e.target.classList.contains(CSS_CLASSES.SESSION_BTN)) { e.stopPropagation(); if(e.target.dataset.act==="rename" && this.onRename) this.onRename(e.target.dataset.id); if(e.target.dataset.act==="delete" && this.onDelete) this.onDelete(e.target.dataset.id); return; }
    const item = e.target.closest(`.${CSS_CLASSES.SESSION_ITEM}`);
    if(item && this.onSess) this.onSess(item.dataset.id);
  }
  onDragStart(e) { if(e.target.classList.contains(CSS_CLASSES.SESSION_ITEM)) { this.dragged=e.target; e.target.classList.add("dragging"); e.dataTransfer.effectAllowed="move"; } }
  onDragEnter(e) { const t=e.target.closest(`.${CSS_CLASSES.SESSION_ITEM}`); if(t && t!==this.dragged) { if(this.draggedOver && this.draggedOver!==t) this.draggedOver.classList.remove("drag-over"); t.classList.add("drag-over"); this.draggedOver=t; } }
  onDragLeave(e) { const t=e.target.closest(`.${CSS_CLASSES.SESSION_ITEM}`); if(t && !t.contains(e.relatedTarget) && t===this.draggedOver) { t.classList.remove("drag-over"); this.draggedOver=null; } }
  onDrop(e) {
    e.preventDefault();
    const t=e.target.closest(`.${CSS_CLASSES.SESSION_ITEM}`);
    if(t && this.dragged && t!==this.dragged) {
      const items=Array.from(this.c.querySelectorAll(`.${CSS_CLASSES.SESSION_ITEM}`));
      if(items.indexOf(this.dragged)<items.indexOf(t)) t.after(this.dragged); else t.before(this.dragged);
      if(this.onReorder) this.onReorder(Array.from(this.c.querySelectorAll(`.${CSS_CLASSES.SESSION_ITEM}`)).map(i=>i.dataset.id));
    }
  }
  onDragEnd() { if(this.dragged) this.dragged.classList.remove("dragging"); this.c.querySelectorAll(`.${CSS_CLASSES.SESSION_ITEM}`).forEach(i=>i.classList.remove("drag-over")); this.dragged=this.draggedOver=null; }
};

// src/shared/constants/storageKeys.ts
var STORAGE_KEYS = { SESSIONS: "sessions", ACTIVE_SESSIONS: "activeSessions" };
var MESSAGE_ACTIONS = { GET_CURRENT_SESSION: "getCurrentSession", SWITCH_SESSION: "switchSession", CLEAR_SESSION: "clearSession" };

// src/popup/services/chromeApi.service.ts
var ChromeApiService = class {
  async getCurrentTab() { const t=await chrome.tabs.query({active:true,currentWindow:true}); if(!t.length) throw new Error("No active tab"); return t[0]; }
  async send(m) { return new Promise(r=>chrome.runtime.sendMessage(m, res=>r(chrome.runtime.lastError?{success:false,error:chrome.runtime.lastError.message}:res))); }
  async get(keys) { return chrome.storage.local.get(keys); }
  async set(d) { return chrome.storage.local.set(d); }
};

// src/popup/services/popup.service.ts
var PopupService = class {
  constructor() { this.api=new ChromeApiService(); this.state={currentDomain:"",currentTab:{},sessions:[],activeSessions:{},currentRename:"",currentDelete:""}; }
  async initialize() {
    try {
      this.state.currentTab=await this.api.getCurrentTab();
      if(!this.state.currentTab.url) throw new ExtensionError("Unable to get current tab URL");
      this.state.currentDomain=getDomainFromUrl(this.state.currentTab.url);
      await this.loadStorage();
      await this.detectActiveSession();
      return {...this.state};
    } catch(e) { throw new ExtensionError(handleError(e,"PopupService.initialize")); }
  }
  async detectActiveSession() {
    try {
      const dom=this.state.currentDomain;
      const domSess=this.state.sessions.filter(s=>s.domain===dom);
      if(!domSess.length) return;
      const res=await this.api.send({action:MESSAGE_ACTIONS.GET_CURRENT_SESSION,domain:dom,tabId:this.state.currentTab.id});
      if(!res.success||!res.data?.cookies) return;
      const curMap=new Map(res.data.cookies.map(c=>[c.name,c.value]));
      let best=null, bestSc=0;
      for(const s of domSess) {
        if(!s.cookies?.length) continue;
        let match=0; for(const c of s.cookies) if(curMap.has(c.name)&&curMap.get(c.name)===c.value) match++;
        const sc=match/s.cookies.length;
        if(sc>bestSc && sc>=0.7) { bestSc=sc; best=s; }
      }
      if(best) { this.state.activeSessions[dom]=best.id; await this.saveStorage(); }
    } catch(e) { console.warn("Session detect fail:",e); }
  }
  async saveCurrent(name) {
    try {
      const res=await this.api.send({action:MESSAGE_ACTIONS.GET_CURRENT_SESSION,domain:this.state.currentDomain,tabId:this.state.currentTab.id});
      if(!res.success) throw new ExtensionError(res.error||"Failed to get session");
      const domSess=this.state.sessions.filter(s=>s.domain===this.state.currentDomain);
      const maxO=domSess.length?Math.max(...domSess.map(s=>s.order??0)):-1;
      const nS={...res.data,id:Date.now().toString(36)+Math.random().toString(36).substr(2),name:name.trim()||"Unnamed Session",domain:this.state.currentDomain,createdAt:Date.now(),lastUsed:Date.now(),order:maxO+1};
      this.state.sessions.push(nS);
      this.state.activeSessions[this.state.currentDomain]=nS.id;
      await this.saveStorage();
      return nS;
    } catch(e) { throw new ExtensionError(handleError(e,"PopupService.saveCurrentSession")); }
  }
  async switchTo(id) {
    try {
      const s=this.state.sessions.find(x=>x.id===id);
      if(!s) throw new ExtensionError("Session not found");
      const res=await this.api.send({action:MESSAGE_ACTIONS.SWITCH_SESSION,sessionData:s,tabId:this.state.currentTab.id});
      if(!res.success) throw new ExtensionError(res.error||"Failed to switch");
      this.state.activeSessions[this.state.currentDomain]=id; s.lastUsed=Date.now();
      await this.saveStorage();
    } catch(e) { throw new ExtensionError(handleError(e,"PopupService.switchToSession")); }
  }
  async clearCurrent() {
    try {
      const res=await this.api.send({action:MESSAGE_ACTIONS.CLEAR_SESSION,domain:this.state.currentDomain,tabId:this.state.currentTab.id});
      if(!res.success) throw new ExtensionError(res.error||"Failed to clear");
      delete this.state.activeSessions[this.state.currentDomain];
      await this.saveStorage();
    } catch(e) { throw new ExtensionError(handleError(e,"PopupService.createNewSession")); }
  }
  async rename(id, name) {
    try { const s=this.state.sessions.find(x=>x.id===id); if(!s) throw new ExtensionError("Not found"); s.name=name.trim()||"Unnamed Session"; await this.saveStorage(); } catch(e) { throw new ExtensionError(handleError(e,"PopupService.renameSession")); }
  }
  async delete(id) {
    try { this.state.sessions=this.state.sessions.filter(x=>x.id!==id); if(this.state.activeSessions[this.state.currentDomain]===id) delete this.state.activeSessions[this.state.currentDomain]; await this.saveStorage(); } catch(e) { throw new ExtensionError(handleError(e,"PopupService.deleteSession")); }
  }
  async reorder(ids) {
    try {
      const dS=this.state.sessions.filter(s=>s.domain===this.state.currentDomain);
      if(ids.length!==dS.length) return;
      ids.forEach((id,i)=>{ const s=dS.find(x=>x.id===id); if(s) s.order=i; });
      await this.saveStorage();
    } catch(e) { console.error(e); }
  }
  get(id) { return this.state.sessions.find(x=>x.id===id); }
  getState() { return {...this.state}; }
  setState(n) { this.state={...this.state,...n}; }
  async loadStorage() { try { const r=await this.api.get([STORAGE_KEYS.SESSIONS,STORAGE_KEYS.ACTIVE_SESSIONS]); this.state.sessions=r[STORAGE_KEYS.SESSIONS]||[]; this.state.activeSessions=r[STORAGE_KEYS.ACTIVE_SESSIONS]||{}; } catch(e) { this.state.sessions=[]; this.state.activeSessions={}; } }
  async saveStorage() { await this.api.set({[STORAGE_KEYS.SESSIONS]:this.state.sessions,[STORAGE_KEYS.ACTIVE_SESSIONS]:this.state.activeSessions}); }
  async getBackup() { return await this.api.get([STORAGE_KEYS.SESSIONS,STORAGE_KEYS.ACTIVE_SESSIONS]); }
  async importBackup(d) { await this.api.set(d); await this.loadStorage(); }
};

// src/popup/index.ts
var PopupController = class {
  constructor() {
    this.load=new LoadingManager(); this.modal=new ModalManager(); this.svc=new PopupService();
    this.siteEl=getElementByIdSafe("currentSite"); this.list=new SessionList(getElementByIdSafe("sessionsList"));
    this.list.setHandlers({onSessionClick:id=>this.switch(id),onRenameClick:id=>this.rename(id),onDeleteClick:id=>this.delete(id),onReorder:ids=>this.svc.reorder(ids)});
    this.bindUI();
  }
  async init() {
    try { this.modal.hideAll(); const st=await this.load.withLoading(()=>this.svc.initialize()); this.siteEl.textContent=st.currentDomain; this.render(); } catch(e) { this.err(handleError(e,"init")); }
  }
  bindUI() {
    getElementByIdSafe("saveBtn").onclick=()=>this.modal.showSaveModal();
    getElementByIdSafe("confirmSave").onclick=async()=>{ try{await this.load.withLoading(()=>this.svc.saveCurrent(this.modal.getSaveInput()));this.modal.hide("save");this.render();}catch(e){this.err(e.message);} };
    getElementByIdSafe("newSessionBtn").onclick=async()=>{ try{await this.load.withLoading(()=>this.svc.clearCurrent());this.render();}catch(e){this.err(e.message);} };
    getElementByIdSafe("confirmRename").onclick=async()=>{ try{const id=this.svc.getState().currentRename; if(id) await this.svc.rename(id,this.modal.getRenameInput());this.modal.hide("rename");this.render();}catch(e){this.err(e.message);} };
    getElementByIdSafe("confirmDelete").onclick=async()=>{ try{const id=this.svc.getState().currentDelete; if(id) await this.svc.delete(id);this.modal.hide("delete");this.render();}catch(e){this.err(e.message);} };
    getElementByIdSafe("exportBtn").onclick=async()=>{ try{const d=await this.svc.getBackup();const b=new Blob([JSON.stringify(d,null,2)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(b);a.download=`sessions-${new Date().toISOString().slice(0,10)}.json`;document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(a.href);}catch(e){this.err(e.message);} };
    const impIn=getElementByIdSafe("importFileInput");
    getElementByIdSafe("importBtn").onclick=()=>impIn.click();
    impIn.onchange=async(e)=>{ const f=e.target.files[0]; if(!f) return; try{const d=JSON.parse(await f.text());if(!d[STORAGE_KEYS.SESSIONS]||!Array.isArray(d[STORAGE_KEYS.SESSIONS]))throw new Error("Invalid");if(confirm("Replace all sessions?")){await this.load.withLoading(()=>this.svc.importBackup(d));this.render();alert("Imported!");}}catch(er){this.err(er.message);}finally{e.target.value="";} };
  }
  async switch(id) {
    const item = document.querySelector(`.session-item[data-id="${id}"]`);
    if(item) {
      const bar = item.querySelector(".session-progress");
      if(bar) {
        bar.style.transition = "none";
        bar.style.width = "0%";
        void bar.offsetWidth;
        bar.style.transition = "width 0.4s cubic-bezier(0.4, 0, 0.2, 1)";
        item.classList.add("loading");
      }
    }
    try {
      await this.svc.switchTo(id);
      this.render();
    } catch(e) {
      this.err(e.message);
    } finally {
      if(item) {
        setTimeout(()=>{
          item.classList.remove("loading");
          const bar = item.querySelector(".session-progress");
          if(bar) { bar.style.width = "0%"; bar.style.transition = "none"; }
        }, 400);
      }
    }
  }
  rename(id) { const s=this.svc.get(id); if(s){this.svc.setState({currentRename:id});this.modal.showRenameModal(s.name);} }
  delete(id) { const s=this.svc.get(id); if(s){this.svc.setState({currentDelete:id});this.modal.showDeleteModal(s.name);} }

  /**
   * Перерисовывает список.
   * Вызывается как внутри (this.render()), так и снаружи из drive-ui.js
   * через window.__popupCtrl.refreshFromStorage()
   */
  render() { const st=this.svc.getState(); this.list.render(st.sessions,st.activeSessions,st.currentDomain); }

  /**
   * Перечитывает storage и перерисовывает список.
   * Используется drive-ui.js после upload/download с Google Drive.
   */
  async refreshFromStorage() {
    await this.svc.loadStorage();
    this.render();
  }

  err(m) { console.error(m); this.modal.showErrorModal(m); }
};

// Инициализация темы
async function initTheme() {
  try {
    const { theme='light' } = await chrome.storage.local.get('theme');
    document.body.dataset.theme = theme;
    const btn = document.getElementById('themeToggle');
    if(btn) btn.textContent = theme==='dark'?'☀️':'🌙';
  } catch(e) { document.body.dataset.theme='light'; }
}

document.addEventListener("DOMContentLoaded", async () => {
  await initTheme();
  const ctrl = new PopupController();
  await ctrl.init();

  // Экспортируем контроллер глобально — drive-ui.js использует его для refresh
  window.__popupCtrl = ctrl;

  // Переключатель темы
  const toggle = document.getElementById('themeToggle');
  if(toggle) {
    toggle.onclick = async () => {
      const next = document.body.dataset.theme==='dark'?'light':'dark';
      document.body.dataset.theme = next;
      toggle.textContent = next==='dark'?'☀️':'🌙';
      await chrome.storage.local.set({theme:next});
    };
  }

  // Отслеживание смены вкладки/домена
  const svc = ctrl.svc;
  let curDom = svc.getState().currentDomain;
  const onAct = async (a) => { try{const t=await chrome.tabs.get(a.tabId);if(t.url){const d=getDomainFromUrl(t.url);if(d!==curDom){curDom=d;await ctrl.init();}}}catch{} };
  const onUpd = async (_,c,t) => { try{if(c.status==="complete"&&t.url){const d=getDomainFromUrl(t.url);if(d!==curDom){curDom=d;await ctrl.init();}}}catch{} };
  chrome.tabs.onActivated.addListener(onAct);
  chrome.tabs.onUpdated.addListener(onUpd);
  window.addEventListener("beforeunload", ()=>{chrome.tabs.onActivated.removeListener(onAct);chrome.tabs.onUpdated.removeListener(onUpd);});
});
})();