"use strict";

/**
 * google-drive.js  —  popup/google-drive.js
 *
 * ВАЖНО: chrome.identity.getAuthToken НЕ РАБОТАЕТ напрямую из popup в MV3.
 * Все вызовы identity и Drive API идут через background service worker
 * (background/index.js) по схеме chrome.runtime.sendMessage.
 */

// ─── HELPERS ─────────────────────────────────────────────────────────────────

/**
 * Отправляет сообщение в background и возвращает ответ.
 * Бросает Error если background вернул { success: false }.
 */
function sendToBackground(payload) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(payload, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      if (!response || !response.success) {
        reject(new Error(response?.error || "Background returned error"));
        return;
      }
      resolve(response.data);
    });
  });
}

// ─── PUBLIC API (вызывается из drive-ui.js) ───────────────────────────────────

/**
 * Показывает окно выбора аккаунта Google и сохраняет токен в background.
 */
async function driveConnect() {
  await sendToBackground({ action: "DRIVE_CONNECT" });
}

/**
 * Тихая проверка — есть ли уже активный токен (без UI).
 * Возвращает true/false.
 */
async function driveCheckConnection() {
  try {
    const result = await sendToBackground({ action: "DRIVE_CHECK" });
    return !!result?.connected;
  } catch (_) {
    return false;
  }
}

/**
 * Загружает все сессии на Google Drive.
 */
async function driveUpload() {
  await sendToBackground({ action: "DRIVE_UPLOAD" });
}

/**
 * Скачивает сессии с Google Drive.
 * @param {"replace"|"merge"} mode
 */
async function driveDownload(mode) {
  await sendToBackground({ action: "DRIVE_DOWNLOAD", mode });
}