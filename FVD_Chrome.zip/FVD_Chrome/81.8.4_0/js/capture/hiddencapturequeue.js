﻿import HiddenCaptureModule from './hiddencapture.js';
import Broadcaster from '../_external/broadcaster.js';

/* FVD_CAPTURE_CONCURRENCY_V1 */
// >>> НАСТРОЙКА: сколько автопревью (скрытых захватов) обрабатываются одновременно.
// Меняй число ниже по своему усмотрению (1, 2, 3...). Рекомендую не больше 3-4:
// каждый захват открывает реальное скрытое окно.
const MAX_SIMULTANEUSELY_CAPTURES = 5;

const HiddenCaptureQueueModule = function (fvdSpeedDial) {
	const HiddenCapture = new HiddenCaptureModule(fvdSpeedDial);
	let queue = [];
	let currentItem = null;
	let nowCapturesInProgressCount = 0; let inProgressIds = [];

	const ignoreIdsAfterComplete = [];

	function checkNeedIgnoreIdAndRemove(id) {
		const removeIndex = ignoreIdsAfterComplete.indexOf(id);

		if (removeIndex !== -1) {
			ignoreIdsAfterComplete.splice(removeIndex, 1);
			return true;
		}

		return false;
	}

	function captureNext() { while (nowCapturesInProgressCount < MAX_SIMULTANEUSELY_CAPTURES && queue.length > 0) { startCapture(); } } function startCapture() { const item = queue.shift();

		currentItem = item; inProgressIds.push(item.id); nowCapturesInProgressCount++;

		HiddenCapture.capture(item.params, function (resultData) {
			if (!checkNeedIgnoreIdAndRemove(item.id)) {

				Broadcaster.sendMessage({
					action: 'hiddencapture:done',
					params: item.params,
					result: resultData,
				});

				if (item.callback) {
					item.callback(resultData);
				}
			}

			const __doneIdx = inProgressIds.indexOf(item.id);
		if (__doneIdx !== -1) { inProgressIds.splice(__doneIdx, 1); }
		if (currentItem === item) { currentItem = null; }
		nowCapturesInProgressCount--;
		captureNext();
		});
	}

	this.removeFromQueueById = function (id) {
		if (inProgressIds.indexOf(id) !== -1) {
			ignoreIdsAfterComplete.push(id);
			return;
		}

		let index = -1;

		for (let i = 0; i !== queue.length; i++) {
			if (queue[i].id === id) {
				index = i;
				break;
			}
		}

		if (index !== -1) {
			queue.splice(index, 1);
		}
	};

	this.getQueue = function () {
		return queue;
	};

	this.getCurrentItem = function () {
		return currentItem;
	};

	this.isEnqueued = function (id) {
		if (currentItem && currentItem.id === id) {
			return true;
		}

		for (let i = 0; i !== queue.length; i++) {
			if (queue[i].id === id) {
				return true;
			}
		}
		return false;
	};

	this.capture = function (params, callback) {
		checkNeedIgnoreIdAndRemove(params.id);

		queue.push({
			id: params.id,
			params: params,
			callback: callback,
		});

		captureNext();
	};

	this.empty = function () {
		queue = [];
	};
};

export default HiddenCaptureQueueModule;
