import Broadcaster from '../_external/broadcaster.js';
import { Utils, _b } from '../utils.js';

export function onHiddenCaptureFinishedTab(fvdSpeedDial, params, resultData) {
	if (!params.elemId) {
		return;
	}

	// update info in speeddial
	const elem = document.getElementById(params.elemId);
	let dialData;

	if (!elem) {
		return;
	}

	Utils.Async.chain([
		function (chainCallback) {
			if (params.type == 'speeddial') {
				fvdSpeedDial.StorageSD.getDial(params.id, function (dial) {
					dialData = dial;

					if (dial.title) {
						//delete resultData.title;
					}

					chainCallback();
				});
			} else if (params.type == 'mostvisited') {
				fvdSpeedDial.MostVisited.getById(params.id, params.interval, 'host', function (row) {
					fvdSpeedDial.MostVisited.extendData(row, function (mvData) {
						if (mvData.title) {
							delete resultData.title;
						}

						dialData = mvData;

						chainCallback();
					});
				});
			}
		},
		function () {
			elem.removeAttribute('loadscreen');

			if (!resultData) {
				// capture failed � apply fallback thumbnail
				_applyFallbackThumb(fvdSpeedDial, elem, dialData, params);
				return;
			}

			if (resultData.title) {
				let titleContainer = elem.querySelector('.head span');

				if (!titleContainer) {
					// try to get titlecontainer for list element
					titleContainer = elem.querySelector('.leftData .text');
				}

				if (titleContainer) {
					titleContainer.textContent = resultData.title;
					elem.removeAttribute('notitle');
				}

				elem.setAttribute(
					'title',
					fvdSpeedDial.SpeedDial.Builder.cellTitle({
						title: resultData.title,
						url: dialData.url,
					})
				);
			}

			const screen = elem.querySelector('.body .preview-image');

			if (
				screen
				&& params.saveImage
				&& resultData.dataUrl
				&& dialData.thumb_source_type == 'screen'
			) {
				Utils.setScreenPreview(screen, resultData.dataUrl, true, false, resultData);
			} else if (screen && params.saveImage && !resultData.dataUrl) {
				// capture succeeded but no image � apply fallback
				_applyFallbackThumb(fvdSpeedDial, elem, dialData, params);
			}
		},
	]);
}

// YouTube video ID extractor
function _getYouTubeVideoId(url) {
	try {
		const u = new URL(url);
		if (u.hostname.includes('youtube.com')) return u.searchParams.get('v');
		if (u.hostname.includes('youtu.be')) return u.pathname.slice(1);
	} catch (e) {}
	return null;
}

// Fallback thumbnail hierarchy:
// 1. YouTube thumbnail
// 2. Favicon + dominant color background
// 3. First letter on colored background
function _applyFallbackThumb(fvdSpeedDial, elem, dialData, params) {
	if (!dialData || !dialData.url) return;

	const screen = elem.querySelector('.body .preview-image');
	if (!screen) return;

	const url = dialData.url;

	// 1. YouTube thumbnail
	const ytId = _getYouTubeVideoId(url);
	if (ytId) {
		const ytThumb = `https://img.youtube.com/vi/${ytId}/maxresdefault.jpg`;
		const img = new Image();
		img.onload = function () {
			if (img.width > 120) {
				Utils.setScreenPreview(screen, ytThumb, false, false, dialData);
				if (params.id && params.type === 'speeddial') {
					fvdSpeedDial.StorageSD.updateDial(params.id, {
						thumb: ytThumb,
						thumb_source_type: 'url',
						thumb_url: ytThumb,
						screen_maked: 1,
					});
				}
			} else {
				_applyFaviconFallback(fvdSpeedDial, elem, screen, dialData, params, url);
			}
		};
		img.onerror = function () {
			_applyFaviconFallback(fvdSpeedDial, elem, screen, dialData, params, url);
		};
		img.src = ytThumb;
		return;
	}

	// 2 & 3. Favicon + color or letter fallback
	_applyFaviconFallback(fvdSpeedDial, elem, screen, dialData, params, url);
}

function _applyFaviconFallback(fvdSpeedDial, elem, screen, dialData, params, url) {
	const faviconUrl = Utils.getFavicon(url);
	const title = dialData.displayTitle || dialData.title || dialData.auto_title || '';
	const letter = String(title || url).replace(/^https?:\/\/(www\.)?/, '').charAt(0).toUpperCase() || '?';

	// Generate a stable color from the URL
	let hash = 0;
	for (let i = 0; i < url.length; i++) hash = url.charCodeAt(i) + ((hash << 5) - hash);
	const hue = Math.abs(hash) % 360;
	const bgColor = `hsl(${hue}, 50%, 40%)`;

	if (faviconUrl) {
		const img = new Image();
		img.crossOrigin = 'anonymous';
		img.onload = function () {
			// Draw favicon centered on colored background canvas
			const size = 320;
			const canvas = document.createElement('canvas');
			canvas.width = size;
			canvas.height = Math.round(size / 1.6);
			const ctx = canvas.getContext('2d');
			ctx.fillStyle = bgColor;
			ctx.fillRect(0, 0, canvas.width, canvas.height);
			const iconSize = 64;
			const x = (canvas.width - iconSize) / 2;
			const y = (canvas.height - iconSize) / 2;
			ctx.drawImage(img, x, y, iconSize, iconSize);

			let dataUrl;
			try {
				dataUrl = canvas.toDataURL('image/jpeg', 0.8);
			} catch (ex) {
				// Favicon server didn't send CORS headers even though we asked
				// for them � the canvas is tainted and can't be exported.
				// Fall back to the plain letter tile instead of throwing.
				_applyLetterFallback(screen, letter, bgColor);
				return;
			}

			Utils.setScreenPreview(screen, dataUrl, false, false, dialData);
			if (params.id && params.type === 'speeddial') {
				fvdSpeedDial.StorageSD.updateDial(params.id, {
					thumb: dataUrl,
					thumb_source_type: 'screen',
					screen_maked: 1,
				});
			}
		};
		img.onerror = function () {
			_applyLetterFallback(screen, letter, bgColor);
		};
		img.src = faviconUrl;
	} else {
		_applyLetterFallback(screen, letter, bgColor);
	}
}

function _applyLetterFallback(screen, letter, bgColor) {
	const size = 320;
	const canvas = document.createElement('canvas');
	canvas.width = size;
	canvas.height = Math.round(size / 1.6);
	const ctx = canvas.getContext('2d');
	ctx.fillStyle = bgColor;
	ctx.fillRect(0, 0, canvas.width, canvas.height);
	ctx.fillStyle = '#ffffff';
	ctx.font = `bold ${Math.round(size * 0.4)}px sans-serif`;
	ctx.textAlign = 'center';
	ctx.textBaseline = 'middle';
	ctx.fillText(letter, canvas.width / 2, canvas.height / 2);
	const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
	Utils.setScreenPreview(screen, dataUrl, false, false, {});
}

export const ThumbManagerModule = function (fvdSpeedDial) {
	this.fvdSpeedDial = fvdSpeedDial;

	this.setThumbToElement = function (params) {
		const data = params.data;
		const elem = params.elem;

		// const screen = elem.querySelector(".body .screen");
		const screen = elem.querySelector('.body .preview-image');
		elem.setAttribute('thumb-source-type', data.thumb_source_type);

		if (data.thumb_source_type == 'screen') {
			if (data.screen_maked != 1) {
				if (data.get_screen_method == 'manual') {
					elem.setAttribute('noscreen', 1);
				} else {
					const captureTimeoutId = setTimeout(() => {
						// still loading after 10s � apply fallback
						if (elem.hasAttribute('loadscreen')) {
							elem.removeAttribute('loadscreen');
							_applyFallbackThumb(fvdSpeedDial, elem, data, {
								id: data.id,
								type: elem.getAttribute('type'),
								saveImage: true,
							});
						}
					}, 10000);
					this.hiddenCaptureThumb({
						data: data,
						type: elem.getAttribute('type'),
						saveImage: true,
						resetScreenMaked: false,
						interval: params.interval,
						elemId: elem.getAttribute('id'),
						elem: elem,
					}, () => clearTimeout(captureTimeoutId));
				}
			} else {
				// setup screen
				if (screen) {
					Utils.setScreenPreview(screen, data.thumb, params.nocache, false, data);
				}
			}
		} else {
			if (screen) {
				if (data.thumb_source_type == 'url' || data.thumb_source_type == 'local_file') {
					Utils.setUrlPreview(
						{
							elem: screen,
							size: params.cellSize,
						},
						{
							url: data.thumb,
							size: {
								width: data.thumb_width,
								height: data.thumb_height,
							},
						},
						params.nocache
					);
				}

				if (data.thumb_source_type === 'custom_preview' && data.previewTitle) {
					Utils.setCustomPreview(screen, data.preview_style, data.previewTitle);
					// const adElem = elem.querySelector('.body .screenParent .add');

					// if (adElem) {
					// 	adElem.style.color = data.preview_style.color;
					// 	adElem.style.border = `1px solid ${data.preview_style.color}`;
					// }
				}

				/*
				if (!data.displayTitle) {
					this.hiddenCaptureThumb({
						data: data,
						type: elem.getAttribute('type'),
						saveImage: false,
						resetScreenMaked: false,
						interval: params.interval,
						elemId: elem.getAttribute('id'),
					});
				}
				*/
			}
		}
	};
	this.hiddenCaptureThumb = function (params, callback) {
		const {
			SpeedDial: { ThumbManagerBg },
		} = fvdSpeedDial;

		if (!params.elem && params.elemId) {
			params.elem = document.getElementById(params.elemId);
		}

		if (params.elem) {
			params.elem.setAttribute('loadscreen', 1);
			Utils.removeScreenPreview(params.elem.querySelector('.preview-image'));
		}

		if (params.elem) {
			delete params.elem;
		}

		ThumbManagerBg.hiddenCaptureThumb(params, res => {
			if (callback) {
				callback(res);
			}
		});

		/*
		Broadcaster.sendMessage({
			action: 'thumbmanager:hiddenCaptureThumb',
			params,
			result: function (res) {
				if (callback) {
					callback(res);
				}
			},
		});
		*/
		/*
		chrome.runtime.sendMessage(
			{
				action: 'thumbmanager:hiddenCaptureThumb',
				params: params,
				wantResponse: callback ? true : false,
			},
			function (res) {
				if (callback) {
					callback(res);
				}
			}
		);
		*/
	};
};