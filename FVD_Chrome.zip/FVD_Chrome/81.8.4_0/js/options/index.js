﻿var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import '../_external/jquery.js';
import '../_external/parallax.js';
import '../_external/qtip/jquery.qtip.min.js';
import '../_external/fix_input_number.js';
import '../colorpicker/jscolor.js';
import '../newtab/contextmenu/dhtmlxmenu.js';
import { default as FvdSpeedDialModule } from '../speedDialCore.js';
import SpeedDialModule from '../newtab/speeddial.js';
import SpeedDialMiscModule from '../newtab/speeddial_misc.js';
import { EventType } from "../types.js";
import PowerOffModule from '../poweroff.js';
import OptionsPowerOffModule from './poweroff.js';
import StorageSD from '../storage.js';
import Sync from '../sync/tab.js';
import UserInfoSync from '../sync/user.js';
import Templates from '../templates.js';
import ContextMenus from '../newtab/contextmenus.js';
import CSSModule from '../newtab/css.js';
import Localizer, { _ } from '../localizer.js';
import RuntimeStore from '../runtimestore.js';
import BackgroundModule from '../newtab/background.js';
import DialogsModule from '../dialogs.js';
import OptionsModule from "./options.js";
import PremiumForShareModule from '../premiumforshare.js';
import AppsModule from "../newtab/apps.js";
import StorageAppsModule from '../storage/apps.js';
import ThumbMakerModule from '../thumbmaker/tab.js';
import ToolTip from '../tooltip.js';
import Broadcaster from '../_external/broadcaster.js';
import { FileSystemSD } from '../storage/filesystem.js';
import { Utils } from '../utils.js';
/* __FVD_LOG_GATE_V1 */
(function () {
  function __fvdLogsOn() {
    try {
      var fsd = (typeof window !== 'undefined' && window.fvdSpeedDial) ? window.fvdSpeedDial : (typeof globalThis !== 'undefined' ? globalThis.fvdSpeedDial : null);
      if (!fsd || !fsd.Prefs) { return true; }
      var v = fsd.Prefs.get('sd.create_logs');
      if (typeof v === 'undefined' || v === null || v === '') { return true; }
      return !(v === false || v === 'false' || v === '0' || v === 0);
    } catch (e) { return true; }
  }
  var __FVD_SUPPRESS = ['[THUMB SWEEP]', '[FVD DIAG]', 'thumbmaker:getimagedatapath', 'Write File', 'Write end for', 'Redundancy set', 'hiddencapture:done', 'To update preview dials count'];
  function __fvdWrapConsole(method) {
    if (!console[method]) { return; }
    var orig = console[method].bind(console);
    console[method] = function () {
      try {
        if (!__fvdLogsOn() && typeof arguments[0] === 'string') {
          for (var i = 0; i < __FVD_SUPPRESS.length; i++) {
            if (arguments[0].indexOf(__FVD_SUPPRESS[i]) !== -1) { return; }
          }
        }
      } catch (e) {}
      return orig.apply(null, arguments);
    };
  }
  __fvdWrapConsole('log');
  __fvdWrapConsole('info');
})();class SettingModule {
    constructor() {
        this.fvdSpeedDial = new FvdSpeedDialModule(this.addEventListener, { mode: "page" });
        this.FileSystem = new FileSystemSD();
        this.init();
    }
    init() {
        return __awaiter(this, void 0, void 0, function* () {
            const { fvdSpeedDial } = this;
            window.fvdSpeedDial = fvdSpeedDial;
            yield fvdSpeedDial.init();
            fvdSpeedDial.Templates = Templates;
            fvdSpeedDial.UserInfoSync = new UserInfoSync(fvdSpeedDial);
            fvdSpeedDial.Sync = Sync;
            fvdSpeedDial.ToolTip = ToolTip;
            fvdSpeedDial.RuntimeStore = new RuntimeStore(fvdSpeedDial);
            fvdSpeedDial.SpeedDial = new SpeedDialModule(fvdSpeedDial);
            fvdSpeedDial.SpeedDialMisc = new SpeedDialMiscModule(fvdSpeedDial);
            fvdSpeedDial.ContextMenus = new ContextMenus(fvdSpeedDial);
            fvdSpeedDial.Options = new OptionsModule(fvdSpeedDial);
            fvdSpeedDial.CSS = new CSSModule(fvdSpeedDial);
            fvdSpeedDial.PowerOff = new PowerOffModule(fvdSpeedDial);
            fvdSpeedDial.Background = new BackgroundModule(fvdSpeedDial);
            fvdSpeedDial.PremiumForShare = new PremiumForShareModule(fvdSpeedDial);
            fvdSpeedDial.Dialogs = new DialogsModule(fvdSpeedDial);
            fvdSpeedDial.Apps = new AppsModule(fvdSpeedDial);
            fvdSpeedDial.StorageApps = new StorageAppsModule(fvdSpeedDial);
            fvdSpeedDial.OptionsPowerOff = new OptionsPowerOffModule(fvdSpeedDial);
            fvdSpeedDial.ThumbMaker = new ThumbMakerModule(fvdSpeedDial);
            this.start();
            this.initEvent();
        });
    }
    addEventListener(eventType, cb) {
        if (eventType === EventType.LOAD) {
            if (document.readyState === 'complete') {
                cb();
            }
            else {
                window.addEventListener('load', (event) => {
                    cb(event);
                });
            }
        }
        else if (eventType === EventType.UNLOAD) {
            window.addEventListener('unload', (event) => {
                cb(event);
            });
        }
    }
    start() {
        const { fvdSpeedDial } = this;
        const { ContextMenus, Options } = fvdSpeedDial;
        fvdSpeedDial.StorageSD = new StorageSD(fvdSpeedDial);
        fvdSpeedDial.StorageSD.connect(() => {
            ContextMenus.init();
            Options.init();
            Localizer.localizeCurrentPage();
            Sync.isActive(function (isActive) {
                document.documentElement.setAttribute("data-sync-active", String(isActive ? 1 : 0));
            });
            const numberInputs = document.querySelectorAll("input[type=\"number\"]");
            for (let i = 0; i !== numberInputs.length; i++) {
                const numberInput = numberInputs[i];
                ((numberInput) => {
                    numberInput.addEventListener("input", () => {
                        const max = parseInt(numberInput.getAttribute("max") || "");
                        const min = parseInt(numberInput.getAttribute("min") || "");
                        if (!isNaN(max) && +numberInput.value > max) {
                            numberInput.value = String(max);
                        }
                        else if (!isNaN(max) && +numberInput.value < min) {
                            numberInput.value = String(min);
                        }
                        if (isNaN(Number(numberInput.value)) || numberInput.value === "") {
                            numberInput.value = String(1);
                        }
                        Options._changeOption(numberInput);
                    }, false);
                })(numberInput);
            }
        });
    }
    initEvent() {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18;
        const { fvdSpeedDial } = this;
        const { ToolTip, Dialogs, Options, StorageSD, Prefs, PowerOff, CSS, SpeedDialMisc, ContextMenus } = fvdSpeedDial;
        const fileSystem = this.FileSystem;
        Broadcaster.onMessage.addListener(function (msg, sender, sendResponse) {
            if (msg.action === 'poweroff:hide') {
                if (!PowerOff.isHidden()) {
                    Prefs.set('poweroff.hidden', true);
                }
            }
            if (msg.action === 'pref:changed' && msg.name === 'sd.display_mode') {
                CSS.prefChanged(msg.name, msg.value);
            }
            if (['user:logout', 'user:login'].includes(msg.action)) {
                globalThis.navigation.reload();
                SpeedDialMisc.refreshSearchPanel();
                ContextMenus.init();
            }
            if (msg.action === 'windowScopeMiscItemGet') {
                fvdSpeedDial.StorageSD.getMisc(msg.data.key, function (result) {
                    if (String(result).indexOf('filesystem') === 0) {
                        fileSystem.readAsDataURLbyURL(result, function (err, data) {
                            sendResponse({ result: data });
                        });
                    }
                    else {
                        sendResponse({ result: result });
                    }
                });
                return true;
            }
            if (msg.action === 'windowScopeMiscItemSet') {
                if (msg.data.key === 'sd.background'
                    && String(msg.data.val).indexOf('https:') === 0) {
                    Utils.imageUrlToDataUrl(msg.data.val, function (dataUrl) {
                        fvdSpeedDial.Prefs.set('sd.background_url', msg.data.val);
                        fvdSpeedDial.StorageSD.setMisc('sd.background', dataUrl, function () {
                            sendResponse({ result: true });
                        });
                    });
                }
                else {
                    if (String(msg.data.val).indexOf('/images/newtab/firefox') !== -1) {
                        msg.data.val = '/images/newtab/fancy_bg.jpg';
                    }
                    fvdSpeedDial.StorageSD.setMisc(msg.data.key, msg.data.val, function () {
                        sendResponse({ result: true });
                    });
                }
                return true;
            }
            if (msg.action === 'windowScopeSaveDial') {
                fvdSpeedDial.StorageSD.syncSaveDial(msg.dial, function (saveInfo) {
                    sendResponse(saveInfo);
                });
                return true;
            }
        });
        window.addEventListener("unload", function () {
            Options.destroy();
        }, false);
        setTimeout(function () {
            const linkToSd = document.getElementById("linkToSD");
            linkToSd.style.top = "-50px";
            linkToSd.addEventListener("webkitTransitionEnd", function () {
                setTimeout(function () {
                    linkToSd.setAttribute("blackshadow", "1");
                }, 500);
            }, false);
        }, 1000);
        (_a = document.getElementById("linkToSD")) === null || _a === void 0 ? void 0 : _a.addEventListener("click", function () {
            document.location = 'newtab.html';
        }, false);
        (_b = document.getElementById("buttonBigSettings")) === null || _b === void 0 ? void 0 : _b.addEventListener("click", function () {
            Options.setType('global');
        }, false);
        (_c = document.getElementById("buttonBigSpeedDial")) === null || _c === void 0 ? void 0 : _c.addEventListener("click", function () {
            Options.setType('speeddial');
        }, false);
        (_d = document.getElementById("buttonBigMostVisited")) === null || _d === void 0 ? void 0 : _d.addEventListener("click", function () {
            Options.setType('mostvisited');
        }, false);
        (_e = document.getElementById("buttonBigRecentlyClosed")) === null || _e === void 0 ? void 0 : _e.addEventListener("click", function () {
            Options.setType('recentlyclosed');
        }, false);
        (_f = document.getElementById("buttonBigBackground")) === null || _f === void 0 ? void 0 : _f.addEventListener("click", function () {
            Options.setType('bg');
        }, false);
        (_g = document.getElementById("buttonBigSdFontColors")) === null || _g === void 0 ? void 0 : _g.addEventListener("click", function () {
            Options.setType('fonts');
        }, false);
        (_h = document.getElementById("buttonBigSdSync")) === null || _h === void 0 ? void 0 : _h.addEventListener("click", function () {
            Options.syncOptionsOpen();
        }, false);
        (_j = document.getElementById("buttonBigSdGetSatisfaction")) === null || _j === void 0 ? void 0 : _j.addEventListener("click", function () {
            Options.openGetSatisfactionSuggestions();
        }, false);
        (_k = document.getElementById("buttonBigSdDonate")) === null || _k === void 0 ? void 0 : _k.addEventListener("click", function (event) {
            Options.openDonateMessage(event);
        }, false);
        (_l = document.getElementById("buttonBigSdPowerOff")) === null || _l === void 0 ? void 0 : _l.addEventListener("click", function (event) {
            Options.setType('poweroff');
        }, false);
        try {
            if (document.getElementById("buttonBigSdWidgets"))
                (_m = document.getElementById("buttonBigSdWidgets")) === null || _m === void 0 ? void 0 : _m.addEventListener("click", function (event) {
                    Options.setType('widgets');
                }, false);
        }
        catch (ex) {
            console.warn(ex);
        }
        (_o = document.getElementById("settingsContent")) === null || _o === void 0 ? void 0 : _o.addEventListener("scroll", function (event) {
            document.getElementById("settingsContent").scrollLeft = 0;
        }, false);
        (_p = document.getElementById("importExport_export")) === null || _p === void 0 ? void 0 : _p.addEventListener("click", function (event) {
            if (!Options.dontAllowIfLocked()) {
                return;
            }
            try {
                Dialogs.importExport({ type: 'export' });
            }
            catch (e) {
                console.log(e);
            }
        }, false);
        (_q = document.getElementById("importExport_import")) === null || _q === void 0 ? void 0 : _q.addEventListener("click", function (event) {
            if (!Options.dontAllowIfLocked()) {
                return;
            }
            Dialogs.importExport({ type: 'import' });
        }, false);
        (function setupCloudButtons() {
  const expBtn = document.getElementById('importExport_export');
  const impBtn = document.getElementById('importExport_import');
  if (!expBtn || !impBtn) { return; }
  const wrap = document.createElement('div');
  wrap.style.display = 'block';
  wrap.style.marginTop = '10px';
  function setProg(btn, p) {
  if (p === null || p === undefined) { btn.style.backgroundImage = ''; return; }
  const pct = Math.round(Math.max(0, Math.min(1, p)) * 100);
  btn.style.backgroundImage = 'linear-gradient(to right, rgba(146,232,146,0.95) 0%, rgba(146,232,146,0.95) ' + pct + '%, rgba(0,0,0,0) ' + pct + '%, rgba(0,0,0,0) 100%)';
}
  const bExp = document.createElement('button');
  bExp.id = 'importExport_export_cloud';
  bExp.className = 'fvdButton';
  bExp.textContent = 'Экспорт в облако Google';
  bExp.style.marginRight = '10px';
  const bImp = document.createElement('button');
  bImp.id = 'importExport_import_cloud';
  bImp.className = 'fvdButton';
  bImp.textContent = 'Импорт из облака Google';
  wrap.appendChild(bExp);
  wrap.appendChild(bImp);
  impBtn.parentNode.insertBefore(wrap, impBtn.nextSibling);
    var fixNode = wrap;
  var fixLevels = 0;
  while (fixNode && fixNode !== document.body && fixLevels < 6) {
    if (fixNode.style) { fixNode.style.height = 'auto'; }
    if (fixNode.tagName === 'FIELDSET') { break; }
    fixNode = fixNode.parentNode;
    fixLevels++;
  }
  bExp.addEventListener('click', function () {
    if (!Options.dontAllowIfLocked()) { return; }
    try { Dialogs.cloudExport(function (p) { setProg(bExp, p); }); } catch (e) { console.log(e); setProg(bExp, null); }
  }, false);
  bImp.addEventListener('click', function () {
    if (!Options.dontAllowIfLocked()) { return; }
    try { Dialogs.cloudImport(function (p) { setProg(bImp, p); }); } catch (e) { console.log(e); setProg(bImp, null); }
  }, false);
})();
(function setupCloudInfoBox() {
  const expBtn = document.getElementById('importExport_export');
  if (!expBtn) { return; }
  const panel = expBtn.closest ? expBtn.closest('fieldset') : null;
  if (!panel || !panel.parentNode) { return; }
  const cont = panel.parentNode;
  const cb1 = document.getElementById('importExport_export_cloud');
  const cb2 = document.getElementById('importExport_import_cloud');
  [cb1, cb2].forEach(function (b) {
    if (b) { b.style.marginRight = '5px'; }
  });
  const box = document.createElement('fieldset');
  const leg = document.createElement('legend');
  leg.textContent = 'Облако';
  box.appendChild(leg);
  const content = document.createElement('div');
  content.style.position = 'absolute';
  content.style.left = '0';
  content.style.right = '0';
  content.style.top = '0';
  content.style.bottom = '0';
  content.style.display = 'flex';
  content.style.alignItems = 'center';
  content.style.justifyContent = 'center';
  const inner = document.createElement('div');
  inner.style.textAlign = 'left';
  content.appendChild(inner);
  box.appendChild(content);
  box.style.position = 'relative';
  box.style.float = 'left';
  box.style.boxSizing = 'border-box';
  box.style.marginLeft = '4px';
  box.style.transition = 'none';
  panel.style.boxSizing = 'border-box';
  panel.style.transition = 'none';
  box.style.overflow = 'hidden';
  cont.insertBefore(box, panel.nextSibling);
  (function () {
    const previewBtnEl = document.getElementById('setAuthoPreview_setPreview');
    if (!previewBtnEl) { return; }
    const previewFs = previewBtnEl.closest ? previewBtnEl.closest('fieldset') : null;
    const dialFs = box.nextElementSibling;
    if (previewFs && dialFs && previewFs !== dialFs && dialFs.parentNode) {
      dialFs.parentNode.insertBefore(previewFs, dialFs.nextSibling);
    }
  })();
  function layoutCloudBox() {
  panel.style.width = '';
  const contRect = cont.getBoundingClientRect();
  const panelRect = panel.getBoundingClientRect();
  if (!contRect.width || !panelRect.width || !panelRect.height) { return; }
  const gap = 14;
  let available = Math.floor(contRect.width - panelRect.width - gap);
  if (available < 150) { available = 150; }
  box.style.width = available + 'px';
  box.style.height = panelRect.height + 'px';
  const br = box.getBoundingClientRect();
  if (Math.abs(br.height - panelRect.height) > 2) {
    box.style.height = Math.round(panelRect.height + (panelRect.height - br.height)) + 'px';
  }
}
layoutCloudBox();

  window.addEventListener('load', layoutCloudBox);
  window.addEventListener('resize', layoutCloudBox);
setTimeout(layoutCloudBox, 250);
setTimeout(layoutCloudBox, 800);
if (window.ResizeObserver) {
  const ro = new ResizeObserver(function () { layoutCloudBox(); });
  ro.observe(panel);
}
  function row(label, value) {
    const r = document.createElement('div');
    r.style.display = 'table-row';
    const c1 = document.createElement('div');
    c1.style.display = 'table-cell';
    c1.style.padding = '3px 0';
    c1.textContent = label;
    const c2 = document.createElement('div');
    c2.style.display = 'table-cell';
    c2.style.padding = '3px 0 3px 10px';
    c2.style.whiteSpace = 'nowrap';
    c2.textContent = '- ' + value;
    r.appendChild(c1);
    r.appendChild(c2);
    return r;
  }
  function render(err, info) {
    inner.textContent = '';
    inner.style.display = 'block';
    if (err) {
      if (err.message === 'NOAUTH') { inner.textContent = 'Нет данных: сначала выполните экспорт или импорт'; }
      else { inner.textContent = 'Проверка не удалась: ' + err.message; }
      return;
    }
    if (!info) { inner.textContent = 'Бэкапов не обнаружено'; return; }
    inner.style.display = 'table';
    if (info.info) {
      inner.appendChild(row('Количество диалов', info.info.dials));
      inner.appendChild(row('Количество групп', info.info.groups));
      inner.appendChild(row('Дата создания бэкапа', info.info.date));
    } else {
      inner.appendChild(row('Файл', info.name));
      inner.appendChild(row('Изменён', new Date(info.modifiedTime).toLocaleString('ru-RU')));
    }
  }
  function refresh() {
    try {
      Dialogs._getCloudInfo(function (err, info) { render(err, info); });
    } catch (e) { inner.textContent = 'Ошибка проверки'; }
  }
  window.fvdCloudInfoRefresh = refresh;
  setTimeout(refresh, 300);
  let hiddenAt = 0;
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) { hiddenAt = Date.now(); }
    else {
      if (hiddenAt && Date.now() - hiddenAt > 30000) { refresh(); }
      hiddenAt = 0;
    }
  });
  document.addEventListener('click', function (e) {
    const t = e.target;
    const txt = t && t.textContent ? String(t.textContent).trim() : '';
    if (txt === 'Главные' || txt === 'Внешний Вид') { setTimeout(refresh, 200); }
  }, true);
  if (Options && Options.setType && !Options._fvdCloudTypeWrapped) {
    Options._fvdCloudTypeWrapped = true;
    const origSetType = Options.setType.bind(Options);
    Options.setType = function () {
      const r = origSetType.apply(Options, arguments);
      setTimeout(refresh, 250);
      return r;
    };
  }
})();








(_r = document.getElementById("sdButtonManageDeny")) === null || _r === void 0 ? void 0 : _r.addEventListener("click", function (event) {
            if (!Options.dontAllowIfLocked()) {
                return;
            }
            Dialogs.manageDeny();
        }, false);
        if (document.getElementById("displayPlusCellsHelp"))
            (_s = document.getElementById("displayPlusCellsHelp")) === null || _s === void 0 ? void 0 : _s.addEventListener("click", function (event) {
                ToolTip.displayImage(document.getElementById("displayPlusCellsHelp"), '/images/help/display_plus_cells.png', event);
            }, false);
        if (document.getElementById("displayQuickMenuHelp"))
            (_t = document.getElementById("displayQuickMenuHelp")) === null || _t === void 0 ? void 0 : _t.addEventListener("click", function (event) {
                ToolTip.displayImage(document.getElementById("displayQuickMenuHelp"), '/images/help/show_quick_menu.png', event);
            }, false);
        (_u = document.getElementById("displayClicksHelp")) === null || _u === void 0 ? void 0 : _u.addEventListener("click", function (event) {
            ToolTip.displayImage(document.getElementById("displayClicksHelp"), '/images/help/show_clicks.png', event);
        }, false);
        if (document.getElementById("displayEnableDialsCounter"))
            (_v = document.getElementById("displayEnableDialsCounter")) === null || _v === void 0 ? void 0 : _v.addEventListener("click", function (event) {
                ToolTip.displayImage(document.getElementById("displayEnableDialsCounter"), '/images/help/dials_counter.png', event);
            }, false);
        if (document.getElementById("displayShowInContextMenuHelp"))
            (_w = document.getElementById("displayShowInContextMenuHelp")) === null || _w === void 0 ? void 0 : _w.addEventListener("click", function (event) {
                ToolTip.displayImage(document.getElementById("displayShowInContextMenuHelp"), '/images/help/display_in_context_menu.png', event);
            }, false);
        if (document.getElementById("displayDialBackgroundHelp"))
            (_x = document.getElementById("displayDialBackgroundHelp")) === null || _x === void 0 ? void 0 : _x.addEventListener("click", function (event) {
                ToolTip.displayImage(document.getElementById("displayDialBackgroundHelp"), '/images/help/hide_background.png', event);
            }, false);
        if (document.getElementById("displayShowGrayLineHelp"))
            (_y = document.getElementById("displayShowGrayLineHelp")) === null || _y === void 0 ? void 0 : _y.addEventListener("click", function (event) {
                ToolTip.displayImage(document.getElementById("displayShowGrayLineHelp"), '/images/help/show_gray_line.png', event);
            }, false);
        (_z = document.getElementById("mainButtonActionHelp")) === null || _z === void 0 ? void 0 : _z.addEventListener("click", function (event) {
            ToolTip.displayImage(document.getElementById("mainButtonActionHelp"), '/images/help/main_button.png', event);
        }, false);
        (_0 = document.getElementById("buttonManageGroups")) === null || _0 === void 0 ? void 0 : _0.addEventListener("click", function (event) {
            if (!Options.dontAllowIfLocked()) {
                return;
            }
            Dialogs.manageGroups({ callback: function (result) {
                    if (result) {
                        Options.rebuildGroupsList();
                    }
                } });
        }, false);
        (_1 = document.getElementById("buttonResetSDClicks")) === null || _1 === void 0 ? void 0 : _1.addEventListener("click", function (event) {
            Dialogs.confirm(_("options_confirm_reset_clicks_title"), _("options_confirm_reset_clicks_text"), function (res) {
                if (res) {
                    StorageSD.resetAllDialsClicks(function () {
                        Dialogs.alert(_("options_success_reset_clicks_title"), _("options_success_reset_clicks_text"));
                    });
                }
            });
        }, false);
        (_2 = document.getElementById("bg_color")) === null || _2 === void 0 ? void 0 : _2.addEventListener("change", function (event) {
            Options.refreshBg();
            document.getElementById('bg_useColor').checked = true;
        }, false);
        (_3 = document.getElementById("bg_imageType")) === null || _3 === void 0 ? void 0 : _3.addEventListener("change", function (event) {
            Options.refreshBgViewType();
        }, false);
        (_4 = document.getElementById("backgroundUploadButton")) === null || _4 === void 0 ? void 0 : _4.addEventListener("click", function (event) {
            document.getElementById("backgroundUploadButton").getElementsByTagName('input')[0].click();
        }, false);
        (_5 = document.getElementById("uploadBackgroundFile")) === null || _5 === void 0 ? void 0 : _5.addEventListener("change", function (event) {
            Options.selectLocalBackground();
        }, false);
        (_6 = document.getElementById("btnLoadAndPreview")) === null || _6 === void 0 ? void 0 : _6.addEventListener("click", function (event) {
            Options.bgLoadAndPreview();
        }, false);
        (_7 = document.getElementById("backgroundButtonRestoreDefault")) === null || _7 === void 0 ? void 0 : _7.addEventListener("click", function (event) {
            Options.bgRestoreDefault();
        }, false);
        (_8 = document.getElementById("helpListElemColor")) === null || _8 === void 0 ? void 0 : _8.addEventListener("click", function (event) {
            ToolTip.displayImage(document.getElementById("helpListElemColor"), '/images/help/text_list_elem_color.png', event);
        }, false);
        (_9 = document.getElementById("helpShowUrlTitleColor")) === null || _9 === void 0 ? void 0 : _9.addEventListener("click", function (event) {
            ToolTip.displayImage(document.getElementById("helpShowUrlTitleColor"), '/images/help/text_list_show_url_title_color.png', event);
        }, false);
        (_10 = document.getElementById("helpTextListLinkColor")) === null || _10 === void 0 ? void 0 : _10.addEventListener("click", function (event) {
            ToolTip.displayImage(document.getElementById("helpTextListLinkColor"), '/images/help/text_list_link_color.png', event);
        }, false);
        if (document.getElementById("helpTextOtherkColor"))
            (_11 = document.getElementById("helpTextOtherkColor")) === null || _11 === void 0 ? void 0 : _11.addEventListener("click", function (event) {
                ToolTip.displayImage(document.getElementById("helpTextOtherkColor"), '/images/help/text_other_color.png', event);
            }, false);
        (_12 = document.getElementById("fontsButtonRestoreDefault")) === null || _12 === void 0 ? void 0 : _12.addEventListener("click", function (event) {
            Options.fontsRestoreDefaults();
        }, false);
        (_13 = document.getElementById("applyChangesButton")) === null || _13 === void 0 ? void 0 : _13.addEventListener("click", function (event) {
            if (!Options.dontAllowIfLocked()) {
                return;
            }
            Options.applyChanges();
        }, false);
        (_14 = document.getElementById("buttonCloseButton")) === null || _14 === void 0 ? void 0 : _14.addEventListener("click", function (event) {
            Options.close();
        }, false);
        (_15 = document.getElementById("setAuthoPreview_setPreview")) === null || _15 === void 0 ? void 0 : _15.addEventListener("click", function (event) {
            Options.setAutoPreviewGlobally();
        }, false);
        (_16 = document.getElementById("sdPreviewSettings_turnOffAutoUpdate")) === null || _16 === void 0 ? void 0 : _16.addEventListener("click", function (event) {
            Options.turnOffAutoUpdateGlobally();
        }, false);
        (_17 = document.getElementById("sdPreviewSettings_setAutoUpdate")) === null || _17 === void 0 ? void 0 : _17.addEventListener("click", function (event) {
            Options.setAutoUpdateGlobally();
        }, false);
        (_18 = document.querySelector(".backupViaEversyncSuggestion button")) === null || _18 === void 0 ? void 0 : _18.addEventListener("click", function () {
            Options.syncOptionsOpen(false, 'backups');
        }, false);
        $("[data-only-in-standard]").qtip({
            content: { text: _("options_available_in_standard_theme_only") },
            position: {
                at: 'top center',
                my: 'bottom center',
            },
            style: {
                classes: "qtip-dark",
                tip: {
                    corner: true,
                    width: 10,
                    height: 4,
                },
            },
            events: {
                show: function (event, api) {
                    return $("#themeSelect").val() !== "standard";
                },
            },
        });
    }
}
/* __FVD_CREATE_LOGS_TOGGLE_V2 */
(function setupCreateLogsToggle() {
function isOn(v) { return !(v === false || v === 'false' || v === '0' || v === 0); }
function apply() {
var host = document.querySelector('.bottomButtons') || document.getElementById('settingsContent'); /* __FVD_CREATE_LOGS_BOTTOM_V1 */
var fsd = window.fvdSpeedDial;
if (!host || !fsd || !fsd.Prefs) { setTimeout(apply, 300); return; }
if (document.getElementById('__fvdCreateLogsBox')) { return; }
var KEY = 'sd.create_logs';
var cur = fsd.Prefs.get(KEY);
try { host.style.position = 'relative'; } catch (e) {}
var box = document.createElement('div');
box.id = '__fvdCreateLogsBox';
box.style.position = 'absolute';
box.style.left = '0';
box.style.right = '0';
box.style.bottom = '0';
box.style.zIndex = '50';
box.style.padding = '6px 12px';
box.style.background = 'rgba(238,238,238,0.95)';
box.style.borderTop = '1px solid #bbb';
var label = document.createElement('label');
label.style.cursor = 'pointer';
var cb = document.createElement('input');
cb.type = 'checkbox';
cb.id = '__fvdCreateLogs';
cb.checked = (typeof cur === 'undefined' || cur === null || cur === '') ? true : isOn(cur);
label.appendChild(cb);
label.appendChild(document.createTextNode(' Создавать логи'));
box.appendChild(label);
if (host && host.parentNode && String(host.className || '').indexOf('bottomButtons') !== -1) { host.parentNode.insertBefore(box, host); } else { box.style.clear = 'both'; host.appendChild(box); } /* __FVD_CREATE_LOGS_BOTTOM_V2 */
cb.addEventListener('change', function () {
fsd.Prefs.set(KEY, cb.checked);
});
}
if (document.readyState === 'complete') { apply(); } else { window.addEventListener('load', apply); }
})();
/* __FVD_SAVE_DEFAULTS_BTN_V1 */
(function setupSaveDefaultsButton() {
function openKv() {
return new Promise(function (resolve) {
try {
var rq = indexedDB.open('FvdDefaultsDir', 1);
rq.onupgradeneeded = function () { rq.result.createObjectStore('kv'); };
rq.onsuccess = function () { resolve(rq.result); };
rq.onerror = function () { resolve(null); };
} catch (e) { resolve(null); }
});
}
function getDir() {
return openKv().then(function (db) {
if (!db) { return null; }
return new Promise(function (res) {
try {
var tx = db.transaction('kv', 'readonly');
var g = tx.objectStore('kv').get('dir');
g.onsuccess = function () { res(g.result || null); };
g.onerror = function () { res(null); };
} catch (e) { res(null); }
});
});
}
function setDir(handle) {
return openKv().then(function (db) {
if (!db) { return; }
try {
var tx = db.transaction('kv', 'readwrite');
tx.objectStore('kv').put(handle, 'dir');
} catch (e) {}
});
}
function collectPrefs() {
var out = {};
var nodes = document.querySelectorAll('[sname]');
for (var i = 0; i < nodes.length; i++) {
var el = nodes[i];
var name = el.getAttribute('sname');
if (!name) { continue; }
if (el.type === 'checkbox') { out[name] = !!el.checked; }
else if (el.type === 'radio') { if (el.checked) { out[name] = el.value; } }
else { out[name] = el.value; }
}
try {
var lg = document.getElementById('__fvdCreateLogs');
if (lg) { out['sd.create_logs'] = !!lg.checked; }
} catch (e) {}
return out;
}
function apply(tries) {
var box = document.getElementById('__fvdCreateLogsBox');
var fsd = window.fvdSpeedDial;
if (!box || !fsd || !fsd.Prefs) {
if ((tries || 0) < 150) { setTimeout(function () { apply((tries || 0) + 1); }, 200); }
return;
}
if (document.getElementById('__fvdSaveDefaultsBtn')) { return; }
var tip = document.createElement('div');
tip.id = '__fvdSaveDefaultsTip';
tip.textContent = 'Сохраняет настройки расширения';
tip.style.cssText = 'position:fixed;display:none;z-index:99999;background:#333;color:#fff;padding:4px 8px;border-radius:4px;font-size:12px;pointer-events:none;transform:translateX(-50%);white-space:nowrap;';
document.body.appendChild(tip);
var btn = document.createElement('button');
btn.id = '__fvdSaveDefaultsBtn';
btn.className = 'fvdButton';
btn.textContent = 'Сохранить по умолчанию';
btn.style.marginLeft = '10px';
btn.addEventListener('mouseenter', function () {
var r = btn.getBoundingClientRect();
tip.style.left = (r.left + r.width / 2) + 'px';
tip.style.top = (r.top - 30) + 'px';
tip.style.display = 'block';
});
btn.addEventListener('mouseleave', function () { tip.style.display = 'none'; });
btn.addEventListener('click', function () {
tip.style.display = 'none';
var old = btn.textContent;
btn.textContent = 'Сохранение...';
(async function () {
try {
var prefs = collectPrefs();
var json = JSON.stringify({ version: 1, savedAt: new Date().toISOString(), prefs: prefs }, null, 2);
var handle = await getDir();
if (!handle || typeof handle.queryPermission !== 'function') {
if (typeof window.showDirectoryPicker !== 'function') { alert('Браузер не поддерживает выбор папки'); return; }
handle = await window.showDirectoryPicker({ id: 'fvd-defaults-dir', mode: 'readwrite' });
await setDir(handle);
}
var perm = await handle.queryPermission({ mode: 'readwrite' });
if (perm !== 'granted') { perm = await handle.requestPermission({ mode: 'readwrite' }); }
if (perm !== 'granted') { alert('Нет разрешения на запись в папку'); return; }
var fh = await handle.getFileHandle('fvd_default_prefs.json', { create: true });
var w = await fh.createWritable();
await w.write(json);
await w.close();
btn.textContent = 'Сохранено';
} catch (e) {
console.warn('[FVD SAVE DEFAULTS] failed', e);
btn.textContent = 'Ошибка сохранения';
}
setTimeout(function () { btn.textContent = old; }, 1500);
})();
});
box.appendChild(btn);
}
if (document.readyState === 'complete') { apply(); } else { window.addEventListener('load', function () { apply(); }); }
})();
new SettingModule();
(function fixCloudButtonsLook() {
  const src = document.getElementById('importExport_export');
  const b1 = document.getElementById('importExport_export_cloud');
  const b2 = document.getElementById('importExport_import_cloud');
  if (!src || !b1 || !b2) { return; }
  b1.className = src.className;
  b2.className = src.className;
  b1.style.cssText = 'margin-right: 10px;';
  b2.style.cssText = '';
})();
